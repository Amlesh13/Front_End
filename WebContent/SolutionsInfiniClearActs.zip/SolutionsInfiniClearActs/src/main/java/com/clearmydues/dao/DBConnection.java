/**
 * This is DBonnection class load the properties file from configuration file
 * properties file include Driver class,user name, password, Databse url.
 * create the connection from MySql database.
 * 
 */
package com.clearmydues.dao;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * @author cmd1
 *
 */

public class DBConnection {

	//This method get connection from Mysql database table.
	public static Connection getConnection() 
	{
		Properties props = new Properties();
		FileInputStream fis = null;
		Connection con = null;
		try
		{
			fis = new FileInputStream("src/main/resources/db.properties");//properties file consists of driver class,user name, password,Databse url
			props.load(fis);

			// load the Driver Class
			Class.forName(props.getProperty("DB_DRIVER_CLASS"));

			
			// create the connection now
			con = DriverManager.getConnection(props.getProperty("DB_URL"),
					props.getProperty("DB_USERNAME"),
					props.getProperty("DB_PASSWORD"));
			//System.out.println(props.getProperty("DB_PASSWORD"));
		} 
		catch (Exception  e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
}
