/**
 * This is ClearActsPromo class 
 * 
 */
package com.clearmydues.troyscrape;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.clearmydues.dao.DBConnection;
import com.clearmydues.mainFunction.PromoSolutionInfiniMain;
/**
 * @author amlesh
 *
 */
public class ClearActsPromo extends PromoSolutionInfiniMain implements Serializable 
{
		Thread thread=new Thread();
		private static Connection connection;
		private static Statement statement;
		private static ResultSet resultSet=null;
		
		
		//default constructor.
		public ClearActsPromo() 
		{
			// TODO Auto-generated constructor stub
		}
	public void scrape() throws Exception
	{
			try
			{
					//url of solutionInfini
				driver.get("https://promo.solutionsinfini.com/txtly");
	
			}
			catch(Exception e)
			{
					e.printStackTrace();
			}
					
			String load_text="";
			for (int second = 0;; second++)
			{
			    if(second >=60)
			    {
			        break;
			    }
			    try
			    {
			    	load_text=driver.findElement(By.xpath("//div[@class='ui-load-more-results ac-load-more']")).getText();
			    	
			    	if((load_text.equals("Show more results...")))
			    	{
			    		thread.sleep(200);
			    		driver.findElement(By.xpath("//div[@class='ui-load-more-results ac-load-more']")).click();	
			    		
			    	}
			
			   }
			    
			    catch(Exception exception)
			    {
			    	//System.out.println(exception);
			    }
		
			}
			
			/*List<WebElement> webElement2=driver.findElements(By.className("tablesaw-cell-content"));
			System.out.println("data size is:"+webElement2.size());
			
				thread.sleep(2000);
				String olddata="";
				String newdata="";
				
				String strArray[]=new String[8];
				
				int colnew =0;
			
				for(int i=0;i<webElement2.size();i++)
				{	
					
					String si="";
	 				String title="";
	 				String txtly="";
	 				String longurl="";
	 				String views="";
	 				String type="";
	 				String lastViewd="";
	 				String dataCreated="";
	 				
	 				try
	 				{
	 					olddata=webElement2.get(i).getText();
	 								
	 				}
					catch(Exception exception)
	 				{
						
						exception.printStackTrace();
						ClearActsPromo clearActs=new ClearActsPromo();
						clearActs.scrapeDownload();
	 				}
				
	 				if(olddata.equals(newdata))
	 				{
	 					//continue;
					
	 				}
	 			
	 				else
	 				{				
	 					newdata=olddata;
	 					boolean b= false;
	 					try 
	 					{
	 						int number = Integer.parseInt(newdata);
	 						b =true;
						
	 					}
	 					catch (Exception e)
	 					{
	 						//System.out.println(e);
	 					}
					
	 					
	 					if(b && colnew>8)
	 					{
	 						String appendString = "";
	 						String scrapedata1= "";
	 						String scrapedata2="";
						
	 						for (int z=0;z<8;z++)
	 						{
	 							appendString =strArray[z];
	 							scrapedata2=scrapedata1+appendString;
	 							scrapedata1=scrapedata2.concat(",");
							
	 						}
						
	 						
	 						colnew=0;
	 						System.out.println(i+" "+scrapedata1);
	 						try
	 						{
	 						String arr[]=scrapedata1.split(",");
						
	 						System.out.println("array length is:" +arr.length);

	 						
	 							si=arr[0];
	 							title=arr[1];
	 							txtly=arr[2];
	 							longurl=arr[3];
	 							views=arr[4];
	 							type=arr[5];
	 							lastViewd=arr[6];
	 							dataCreated=arr[7];
	 						}
	 							catch(Exception e)
	 			 				{
	 			 					e.printStackTrace();
	 			 				}
	 			 						
	 						try
	 						{
									thread.sleep(2000);
									connection=DBConnection.getConnection();
									statement=connection.createStatement();
									statement.executeUpdate("INSERT INTO `promosolutioninfini`(SI,Title,Txtly,Long_Url,Views,Type,Last_Viewed,Date_Created)VALUE('"+si+"','"+title+"','"+txtly+"','"+longurl+"','"+views+"','"+type+"','"+lastViewd+"','"+dataCreated+"')");
							
							}
							catch(Exception exception)
							{
									exception.printStackTrace();
							}	
					
	 					}
	 					if (colnew<8)
	 						strArray[colnew] = olddata;
	 					colnew++;
	 				
	 				}	
				}		
				
				try
				{
					ClearActsPromo clearActsPromo=new ClearActsPromo();
					clearActsPromo.scrapeDownload();//call Log Download Method 
				}	
				catch(Exception exception)
				{
					exception.printStackTrace();
				}
				
*/	}		
	
		public void scrapeDownload() throws Exception
		{
				System.out.println("called");
				//thread.sleep(4000);
				List<WebElement> webElement1=driver.findElements(By.className("row-actions"));
				//System.out.println("view log size is:"+webElement1.size());
				boolean check=false;
				int pointer=0;
				while(check==false)
				{	
					for(int i=163;i<webElement1.size();i++)
					{	
						try
						{
							String query="select Id from promosolutioninfini where Taken=0 limit 1";
							thread.sleep(2000);
							connection=DBConnection.getConnection();
							statement=connection.createStatement();
							resultSet = statement.executeQuery(query);
						}
				
						catch (Exception exception)
						{
							exception.printStackTrace();
						}	
						
						int id_temp=0;
						while (resultSet.next())
						{ 
							 id_temp=resultSet.getInt("Id");
							 System.out.println("id is:" +id_temp);
						}	
				
						//get the main browser handle
						String parentWindow = driver.getWindowHandle();
			
						WebElement link = webElement1.get(i).findElement(By.cssSelector("a[href*='https://promo.solutionsinfini.com/txtly/logs?id']"));
						link = webElement1.get(i+1).findElement(By.cssSelector("a[href*='https://promo.solutionsinfini.com/txtly/logs?id']"));
						Actions newTab = new Actions(driver);
						thread.sleep(3000);
						
						//System.out.println("Go "+link.getAttribute("href"));
						thread.sleep(3000);
						String sr=link.getAttribute("href");
						
						try
						{
							thread.sleep(3000);
							if(i==1)
								newTab.keyDown(Keys.SHIFT).click(link).keyUp(Keys.SHIFT).build().perform();
						
							thread.sleep(5000);
							link.sendKeys(Keys.CONTROL + "n");
							thread.sleep(5000);
						
							Set<String> handles =  driver.getWindowHandles();
							for(String windowHandle  : handles)
							{
								if(!windowHandle.equals(parentWindow))
								{
									driver.switchTo().window(windowHandle);
									driver.get(sr);
								}
							}
						
						}
						catch(Exception e)
						{
							//e.printStackTrace();
							//System.out.println(e);
						
						i=i+1;
						WebElement link1 = webElement1.get(i).findElement(By.cssSelector("a[href*='https://promo.solutionsinfini.com/txtly/logs?id']"));
					
						link1.sendKeys(Keys.CONTROL + "n");
						thread.sleep(2000);
						Set<String> handles =  driver.getWindowHandles();
						for(String windowHandle  : handles)
						{
							if(!windowHandle.equals(parentWindow))
							{
								driver.switchTo().window(windowHandle);
								driver.get(sr);
								
							}
						}
							
						}
						
						String load_page="";
						String load_page1="";
						int l=1;
						for (int second = 0;; second++)
						{
						    if(second >=60)
						    {
						        break;
						    }
						    try
						    {
						    	load_page=driver.findElement(By.xpath("//div[@class='ui-load-more-results ac-load-more']")).getText();
						    	
						    	if((load_page.equals("Show more results...")))
						    	{
						    		thread.sleep(200);
						    		driver.findElement(By.xpath("//div[@class='ui-load-more-results ac-load-more']")).click();	
						    		//System.out.println("click done");
						    	}
						    	
						    	load_page1=driver.findElement(By.cssSelector("a[href*='http://promo.solutionsinfini.com/txtly/logs?id']")).getText();
						    	
						    	int d=Integer.parseInt(load_page1);
						    	System.out.println(d);
						    	if(d==l)
						    	{	thread.sleep(200);
						    		driver.findElement(By.cssSelector("a[href*='http://promo.solutionsinfini.com/txtly/logs?id']")).click();	
						    		System.out.println("click done");
						    		l++;
						    	}
						   }
						    
						    catch(Exception exception)
						    {
						    	System.out.println(exception);
						    }
					
						}
								
							System.out.println("load page is done");
							thread.sleep(2000);
							List<WebElement> webElement3=driver.findElements(By.className("tablesaw-cell-content"));
							//System.out.println("data size is:"+webElement3.size());
				 			thread.sleep(2000);
							
				 			int a=webElement3.size();
				 			String data1="";
				 			String data="";
				 			
				 			String str[]=new String[11];
				 			
				 			int col =0;
				 			
							
				 			for(int k=0;k<webElement3.size();k++)
				     		{	
				 				String si="";
				 				String browser="";
				 				String device_Type="";
				 				String device_Brand="";
				 				String platform="";
				 				String host="";
				 				String mobile="";
				 				String ip_Address="";
				 				String city="";
				 				String region="";
				 				String visted_On="";
				 				
								data1=webElement3.get(k).getText();
							
								if(data1.equals(data))
								{	
									//continue;
								}
								else
								{
									data=data1;
									//System.out.println(k+" "+data);
									boolean b= false;
									try 
									{
										int number = Integer.parseInt(data);
										b =true;
									}
									catch (Exception e){}
									String scrapedata1= "";
									String scrapedata2="";
								
									if(b && k>11) 
									{
										String str1 = "";
										for (int z=0;z<11;z++)
										{	
										str1 =str[z];
										scrapedata2=scrapedata1+str1;
										scrapedata1=scrapedata2.concat(",");
										}
										col=0;
										//System.out.println(k+" "+scrapedata1);
										String arr[]=scrapedata1.split(",");
										//System.out.println("array length is:" +arr.length);
										try
										{
											si=arr[0];
											browser=arr[1];
											device_Type=arr[2];
											device_Brand=arr[3];
											platform=arr[4];
											host=arr[5];
											mobile=arr[6];
											ip_Address=arr[7];
											city=arr[8];
											region=arr[9];
											visted_On=arr[10];
										}
										catch(Exception e )
										{
											//e.printStackTrace();
										}
										try
										{
											thread.sleep(2000);
											connection=DBConnection.getConnection();
											statement=connection.createStatement();
											statement.executeUpdate("INSERT INTO `psw`(SI,Browser,Device_Type,Device_Brand,Platform,Host,Mobile,Ip_Address,City,Region,Visted_On,ID)VALUE('"+si+"','"+browser+"','"+device_Type+"','"+device_Brand+"','"+platform+"','"+host+"','"+mobile+"','"+ip_Address+"','"+city+"','"+region+"','"+visted_On+"','"+id_temp+"')");
											//System.out.println("data saved");
										}
										catch(Exception exception)
										{
											exception.printStackTrace();
										}	
											
									}
								if (col<11)
									str[col] = data1;
									
									col++;
									}
					 		}		
						try
						{
							thread.sleep(2000);
							driver.close(); //closing the child window
							thread.sleep(2000);
				   			driver.switchTo().window(parentWindow); //cntrl to parent window
						}
						catch(Exception exception)
						{
							//exception.printStackTrace();
						}
				
						try
						{
								String query1="update promosolutioninfini set Taken=1 where id="+id_temp;     
								statement.executeUpdate(query1);
						}
						
						catch(Exception exception)
						{
							//exception.printStackTrace();
						}
						
						
						pointer=pointer+1;    
						resultSet.close();
						statement.close();
						
						if(pointer==0)
							{
								check=true;
								driver.get("https://promo.solutionsinfini.com/members/logout");
								driver.close();
							}
	
					}//while close	
				}
						
		}
		
	}
