/**
 * 
 * This is Main class execution point of the  PromoSolutionInfiniSite.
 * Main class where  scrape() method being calling
 * 
 */
package com.clearmydues.mainFunction;

import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.clearmydues.troyscrape.ClearActs;
import com.clearmydues.troyscrape.ClearActsPromo;

/**
 * 
 * @author amlesh
 * 
 */
public class PromoSolutionInfiniMain 
{
	
	public static WebDriver driver;
	
	Thread thread=new Thread();

	/**
	 * @param args
	 * 
	 */
	
	public static void main(String[] args) throws Throwable 
	{
		// TODO Auto-generated method stub

	
		ClearActsPromo clearActsPromo=new ClearActsPromo();
		
		
		Properties props = new Properties();
		FileInputStream fis = null;
		Connection con = null;
		String promo_username="";
		String promo_password="";
		try
		{
			fis = new FileInputStream("src/main/resources/promo.properties");
			props.load(fis);
			
			//System.out.println("load done");
		
			promo_username=props.getProperty("promo_username");
			promo_password=props.getProperty("promo_password");
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver = new FirefoxDriver();
		driver.get("https://promo.solutionsinfini.com/txtly");
		
		//load username and password from properties file.
		
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(promo_username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(promo_password);
		driver.findElement(By.xpath("//input[@name='login']")).click();
		
		clearActsPromo.scrape();
		clearActsPromo.scrapeDownload();
	}


}
