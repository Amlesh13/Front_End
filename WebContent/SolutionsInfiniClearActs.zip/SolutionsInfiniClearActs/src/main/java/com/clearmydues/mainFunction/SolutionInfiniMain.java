/**
 * 
 * This is Main class execution point of the  SolutionInfiniSite.
 * Main class where  scrape() method being calling
 * 
 */
package com.clearmydues.mainFunction;

import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.clearmydues.troyscrape.ClearActs;


/**
 * 
 * @author amlesh
 * 
 */
public class SolutionInfiniMain 
{
	
	public static WebDriver driver;
	
	Thread thread=new Thread();

	/**
	 * @param args
	 * 
	 */
	
	public static void main(String[] args) throws Throwable 
	{
		// TODO Auto-generated method stub

	
		ClearActs clearActs=new ClearActs();
		
		Properties props = new Properties();
		FileInputStream fis = null;
		Connection con = null;
		String username="";
		String password="";
		try
		{
			fis = new FileInputStream("src/main/resources/db.properties");
			props.load(fis);
			
			//System.out.println("load done");
		
			username=props.getProperty("username");
			password=props.getProperty("password");
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver = new FirefoxDriver();
		driver.get("https://alerts.solutionsinfini.com/txtly");
		
		//load username and password from properties file.
		
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@name='login']")).click();
		
		clearActs.scrape();
		
	}


}
